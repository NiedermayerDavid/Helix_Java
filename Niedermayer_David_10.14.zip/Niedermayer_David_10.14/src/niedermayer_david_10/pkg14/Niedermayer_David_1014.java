package niedermayer_david_10.pkg14;


public class Niedermayer_David_1014 {

    public static void main(String[] args) {

    }

}
